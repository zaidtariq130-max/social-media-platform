import type { ThemeColors } from "./types"

export const colors: ThemeColors = {
  primary: "#2563eb",
  secondary: "#64748b",
  background: "#ffffff",
  cardBackground: "#ffffff",
  text: "#0f172a",
  danger: "#e11d48",

  secondaryBackground: "#f1f5f9",
  secondaryText: "#334155",
  border: "#cbd5e1",

  outlineBackground: "#ffffff",
  ghostBackground: "#f1f5f9",


  iconActive: "#2563eb",
  iconInactive: "#64748b",
  iconHover: "#0f172a",
  activeBackground: "#eff6ff",
  activeBorder: "#bfdbfe",

  gradientStart: "#3b82f6",
  gradientEnd: "#1d4ed8",
  inputBackground: "#f1f5f9",
  mutedText: "#94a3b8",

  sidebarBackground: "#ffffff",
  headerBackground: "#ffffff",
  dangerBackground: "#fff1f2",
  overlay: "rgba(15, 23, 42, 0.4)",
}

export const gradients = {
  primary: `linear-gradient(135deg, ${colors.gradientStart}, ${colors.gradientEnd})`,
}
