import type { ThemeSpacing } from "./types"

export const spacing: ThemeSpacing = {


  xs: "4px",
  sm: "8px",
  md: "16px",
  lg: "24px",
  xl: "32px",
  xxl: "48px",
}